# ExamenesPOSIX
Examenes de POSIX comentados 

> gcc -Wall -Wextra -Werror -pthread -o main main.c -lpthread -lrt
>
**añadir -lm si se usan funciones de math.h**
>
> ./main
